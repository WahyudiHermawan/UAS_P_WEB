$(document).on('click','#btn-edit-loket', function(){
    $('.modal-body #id-loket').val($(this).data('id'));
    $('.modal-body #nama').val($(this).data('nama'));
    $('.modal-body #keterangan').val($(this).data('keterangan'));
    $('.modal-body #pelayanan').val($(this).data('pelayanan'));
})
$(document).on('click','#btn-edit-pelayanan', function(){
    $('.modal-body #id-pelayanan').val($(this).data('id'));
    $('.modal-body #nama').val($(this).data('nama'));
    $('.modal-body #keterangan').val($(this).data('keterangan'));
    $('.modal-body #kode').val($(this).data('kode'));
})