<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <div class="col-12">
        Pelayanan Loket 1 (Customer Service)
    </div>
    <div class=card>
        <div class="card-body">
            <div class="container">
                <div class="row">
                    <div class="col-dilayani">
                        <div class="dilayani">
                            <h5>Sedang Dilayani</h5>
                            <p>A03</p>
                        </div>
                        <button type="button" class="btn-selesai">Selesai</button>
                    </div>
                    <div class="daftar">
                        <h4>Daftar Antrian Selanjutnya</h4>
                        <table class="table" border="1" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>No Antrian</th>
                                    <th>Panggil</th>
                                    <th>Keterangan</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>A02</td>
                                    <td><a href="panggil.php">Panggil</a></td>
                                    <td>Ada</td>
                                </tr>
                                
                            </tbody>
                        </table>

                    </div>



                </div>
            </div>
        </div>
    </div>


</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->