<!-- Begin Page Content -->
<div class="container-fluid">


    <div class=card>
        <div class="card-header">
            <div class="row">
                <div class="col-8">
                    <h5 class="card-text">Dashboard</h5>
                </div>
                <div class="col-4">
                    <div class="float-sm-right">
                        <a href="/antrian/ambil" class="btn btn-primary btn-sm">
                            <i class="fa fa-plus"></i> <span>Ambil Antrian</span>
                        </a>
                    </div>
                </div>

            </div>
        </div>
        <div class="card-body">
            <div class="container">
                <div class="row">
                    <!-- Page Heading -->
                    <div class="col-12">
                        Dashboard Antrian
                    </div>
                    <br>
                    <div class="antrian">
                        <h5>Panggilan Antrian</h5>
                        <p>C02</p>
                        <h5>Loket 1</h5>
                    </div>
                    <div class="col-5">
                        <div class="carousel-item  active ">
                            <iframe width="530" height="270" src="https://www.youtube.com/embed/VckqV2wC1gs" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                        </div>
                    </div>
                    <br>
                    <!-- <div class="antrian">
                        <h5>Panggilan Antrian</h5>
                        <p>A03</p>
                        <h5>Loket 1</h5>
                    </div> -->
                    <div class="loket">
                        <p>A03</p>
                        <h5>Loket 1</h5>
                    </div>
                    <div class="loket">
                        <p>A03</p>
                        <h5>Loket 1</h5>
                    </div>
                    <div class="loket">
                        <p>A03</p>
                        <h5>Loket 1</h5>
                    </div>
                    <div class="loket">
                        <p>A03</p>
                        <h5>Loket 1</h5>
                    </div>
                    <div class="loket">
                        <p>A03</p>
                        <h5>Loket 1</h5>
                    </div>


                </div>
            </div>
        </div>
    </div>


</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->