<?php

namespace App\Controllers;

class LoketPanggil1 extends BaseController
{
    public function __construct()
    {
        helper('sn');
    }
    public function index()
    {

        $data = [
            'judul' => 'Loket 1'
        ];
        tampilan('loketpanggil/loket1', $data);
    }
}
